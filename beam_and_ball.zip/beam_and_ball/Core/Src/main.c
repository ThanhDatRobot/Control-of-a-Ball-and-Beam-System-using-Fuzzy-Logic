/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "i2c-lcd.h"
#include "stdio.h"
#include "string.h"
#include "stdlib.h"
#include "math.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
	float e[7];
	float edot[7];
	float ce[7] = {-0.6, -0.4, -0.2, 0, 0.2, 0.4, 0.6}; // Error range for fuzzy logic
	float cedot[7] = {-0.7, -0.4, -0.2, 0, 0.2, 0.4, -0.7}; // Error rate of change range for fuzzy logic

	float Ke =1/20.000;
	float Kedot = 1/100.000; //100.00
	float Ku = 90; // do

	float integral_error = 0.0f;   // Biến tích phân để lưu tích lũy sai số
	float Ki = 1.0f;              // Hệ số tích phân, điều chỉnh tùy theo độ nhạy mong muốn
	float disturbance_compensation = 0.0f;  // Giá trị bù tín hiệu do tích phân
	float max_compensation = 10;

	float y_out[7] = {-1, -0.4, -0.2, 0, 0.2, 0.4, 1}; // Output values for fuzzy logic
	float y_s;
	float error = 0; // Example error value
	float errordot = 0;

	float beta[7][7];
	int low_servo = 27;
	int high_servo = 130;
	int ccr_value; // The CCR1 value for PWM

	uint32_t IC_Val1 = 0;
	uint32_t IC_Val2 = 0;
	uint32_t Difference = 0;
	uint8_t Is_First_Captured = 0;  // is the first value captured ?
	float Distance = 0;
	float dis = 0;
	float dis_past=0;
	float dis_setpoint=0;
	int initial_angle = 95;
	int ccr_initial = 0;

	uint32_t previous_time = 0;
	float time_sample = 0;

	float data = 0.5;
	char chuoi[32];

	volatile uint8_t state = 0;
	volatile uint8_t flagStartControlLoop = 0;
	volatile uint8_t sleepflag = 0;

	// Các biến và hằng số
	#define UART_BUFFER_SIZE 3
	#define MAX_SETPOINT 50
	#define MIN_SETPOINT 0
	uint8_t UART2_rxBuffer[UART_BUFFER_SIZE] = {0};
	#define BUFFER_SIZE 64
	uint8_t txBuffer[BUFFER_SIZE] = "Hello from STM32!";
	uint8_t rxBuffer[BUFFER_SIZE];

	float current_angle = 95;          // Góc hiện tại của servo
	float target_angle = 95;           // Góc mục tiêu của servo
	int step_size = 1;                 // Mức tăng/giảm mỗi lần để tiến gần tới target
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim2;

UART_HandleTypeDef huart2;
DMA_HandleTypeDef hdma_usart2_rx;
DMA_HandleTypeDef hdma_usart2_tx;

/* USER CODE BEGIN PV */
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_TIM1_Init(void);
static void MX_I2C1_Init(void);
static void MX_TIM2_Init(void);
static void MX_USART2_UART_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
// Các hàm chính
void processControlInput();
float extractSetpoint(char* buffer);
void moveToInitialPosition(int initial_angle, int target_angle, int step_size);
float smoothTransition(float current, float target, float proportional_factor);
float stringToFloat(char* str);
float triangularMembershipFunction(float x, float L, float C1, float C2, float R);
float fuzzyLogic();


void delay(uint16_t time){
	__HAL_TIM_SET_COUNTER(&htim1, 0);
	while(__HAL_TIM_GET_COUNTER(&htim1) < time);
}

void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
{
	if (htim->Channel == HAL_TIM_ACTIVE_CHANNEL_1)  // if the interrupt source is channel1
	{
		if (Is_First_Captured==0) // if the first value is not captured
		{
			IC_Val1 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_1); // read the first value
			Is_First_Captured = 1;  // set the first captured as true
			// Now change the polarity to falling edge
			__HAL_TIM_SET_CAPTUREPOLARITY(htim, TIM_CHANNEL_1, TIM_INPUTCHANNELPOLARITY_FALLING);
		}
		else if (Is_First_Captured==1)   // if the first is already captured
		{
			IC_Val2 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_1);  // read second value
			__HAL_TIM_SET_COUNTER(htim, 0);  // reset the counter

			if (IC_Val2 > IC_Val1)
			{
				Difference = IC_Val2-IC_Val1;
			}
			else if (IC_Val1 > IC_Val2)
			{
				Difference = (0xffff - IC_Val1) + IC_Val2;
			}
			Distance = Difference * .034/2;
			Is_First_Captured = 0; // set it back to false
			// set polarity to rising edge
			__HAL_TIM_SET_CAPTUREPOLARITY(htim, TIM_CHANNEL_1, TIM_INPUTCHANNELPOLARITY_RISING);
			__HAL_TIM_DISABLE_IT(&htim1, TIM_IT_CC1);
		}
	}
}

float HCSR04_GetDis (void)  // Thay đổi kiểu trả v ? từ uint8_t sang float
{
    HAL_GPIO_WritePin(TRIG_GPIO_Port, TRIG_Pin, GPIO_PIN_SET);  // Kéo chân TRIG lên HIGH
    delay(10);  // Ch ? 10 us
    HAL_GPIO_WritePin(TRIG_GPIO_Port, TRIG_Pin, GPIO_PIN_RESET);  // Kéo chân TRIG xuống LOW

    __HAL_TIM_ENABLE_IT(&htim1, TIM_IT_CC1);
    return Distance;  // Trả v ? giá trị float Distance
}

void displayMessage(char* message)
{
    lcd_put_cur(0, 0);
    lcd_send_string(message);
}

/* Callback cho DMA nhận UART */
// Callback DMA UART nhận dữ liệu
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
    if (huart->Instance == USART2) {
        processControlInput();  // Xử lý tín hiệu điều khiển
        HAL_UART_Receive_DMA(&huart2, UART2_rxBuffer, UART_BUFFER_SIZE);  // Tiếp tục nhận
    }
}

void clearLCD()
{
    lcd_clear();
}


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_TIM1_Init();
  MX_I2C1_Init();
  MX_TIM2_Init();
  MX_USART2_UART_Init();
  /* USER CODE BEGIN 2 */
  HAL_UART_Receive_DMA(&huart2, UART2_rxBuffer, UART_BUFFER_SIZE);  // Bắt đầu nhận dữ liệu qua DMA
  //HAL_UART_Receive_IT(&huart2, uartRxBuffer, 1);
  HAL_TIM_IC_Start_IT(&htim1, TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);

  lcd_init ();

  displayMessage("Beam and Ball");
  HAL_Delay(2000); // Delay 2 giây
  clearLCD();
  displayMessage("Start with me!!!");
  HAL_Delay(1000); // Delay 2 giây
  clearLCD();

  sprintf((char*)txBuffer, "Press 's' to start");
  HAL_UART_Transmit_IT(&huart2, txBuffer, strlen((const char*)txBuffer));

  moveToInitialPosition(25, 100, 1); //Dua beam ve vi tri ban dau
  uint32_t current_time = HAL_GetTick(); // Get the current time in ms

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  if (flagStartControlLoop)
      {
        	  //Calculate sample time
			  uint32_t new_time = HAL_GetTick();
			  time_sample = (float)(new_time - current_time) / 1000.0f;
			  current_time = new_time;

			  // Get current distance
			  dis = HCSR04_GetDis();

			  // Calculate error and limit within [-1, 1]
			  error = (float)(dis_setpoint - dis) * Ke;
			  if (error > 1) error = 1;
			  else if (error < -1) error = -1;

			  // Calculate derivative of the error
			  errordot = (float)(((dis_setpoint - dis) - (dis_setpoint - dis_past)) / time_sample) * Kedot;
			  dis_past = dis;

			  // Kiểm tra điều kiện ma sát để kích hoạt thành phần tích phân
			  if (fabs(errordot) < 0.0025 && fabs(error / Ke) > 1) {
			      integral_error += error * time_sample;  // Cộng dồn sai số vào tích phân

			      // Giới hạn tích phân để tránh quá mức
			      if (integral_error > max_compensation) {
			          integral_error = max_compensation;
			      } else if (integral_error < -max_compensation) {
			          integral_error = -max_compensation;
			      }

			      disturbance_compensation = Ki * integral_error/Ke;  // Tính thành phần bù tích phân
			  } else {
			      // Reset tích phân khi không thỏa mãn điều kiện ma sát
			      integral_error = 0.0f;
			      disturbance_compensation = 0.0f;
			  }

			  // Fuzzy logic output plus integral control to combat friction
			  y_s = fuzzyLogic();

			  // Calculate target_angle from fuzzy logic and integral output
			  float control_output = y_s * Ku;
			  target_angle = control_output + 105 + disturbance_compensation;

			  // Limit target_angle within [70, 120]
			  if (target_angle > 130) target_angle = 135;
			  else if (target_angle < 60) target_angle = 60;

			  // Smoothly adjust current_angle towards target_angle
			  current_angle = smoothTransition(current_angle, target_angle, 0.35);

			  // Convert current_angle to PWM value for servo
			  int ccr_value = (current_angle * (high_servo - low_servo)) / 180 + low_servo;
			  __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, ccr_value);

			  // Display information on LCD
			  lcd_put_cur(0, 0);
			  lcd_send_string("Dist: ");
			  sprintf(chuoi, "%.2f", dis);
			  lcd_send_string(chuoi);

			  lcd_put_cur(1, 0);
			  sprintf(chuoi, "S: %.0f A: %.1f", dis_setpoint, target_angle);
			  lcd_send_string(chuoi);

			  HAL_Delay(1);

      }

      // Kiểm tra lệnh UART trong buffer DMA
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 100;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 100000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_IC_InitTypeDef sConfigIC = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 100-1;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 0xffff-1;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_IC_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_RISING;
  sConfigIC.ICSelection = TIM_ICSELECTION_DIRECTTI;
  sConfigIC.ICPrescaler = TIM_ICPSC_DIV1;
  sConfigIC.ICFilter = 0;
  if (HAL_TIM_IC_ConfigChannel(&htim1, &sConfigIC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 2000-1;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 1000-1;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */
  HAL_TIM_MspPostInit(&htim2);

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */
}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Stream5_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream5_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream5_IRQn);
  /* DMA1_Stream6_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream6_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream6_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(TRIG_GPIO_Port, TRIG_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : TRIG_Pin */
  GPIO_InitStruct.Pin = TRIG_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(TRIG_GPIO_Port, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
float triangularMembershipFunction(float x, float L, float C1, float C2, float R) {
  float val;
  if (x < L) {
    val = 0;
  } else if (x < C1) {
    val = (x - L) / (C1 - L);
  } else if (x < C2) {
    val = 1;
  } else if (x < R) {
    val = (R - x) / (R - C2);
  } else {
    val = 0;
  }
  if (val < 0.01) val = 0;  // Giảm ảnh hưởng của giá trị gần ranh giới
  return val;
}
// Fuzzy logic calculation
float fuzzyLogic() {
  // Calculate membership values for error
  e[0] = triangularMembershipFunction(error, -3, -2, ce[0], ce[1]);   		// NB
  e[1] = triangularMembershipFunction(error, ce[0], ce[1], ce[1], ce[2]);  	// NM
  e[2] = triangularMembershipFunction(error, ce[1], ce[2], ce[2], ce[3]);  	// NS
  e[3] = triangularMembershipFunction(error, ce[2], ce[3], ce[3], ce[4]);  	// ZE
  e[4] = triangularMembershipFunction(error, ce[3], ce[4], ce[4], ce[5]);  	// PS
  e[5] = triangularMembershipFunction(error, ce[4], ce[5], ce[5], ce[6]);  	// PM
  e[6] = triangularMembershipFunction(error, ce[5], ce[6], 2, 3);      		// PB

  // Calculate membership values for error rate of change
  edot[0] = triangularMembershipFunction(errordot, -3, -2, cedot[0], cedot[1]);   			// NB
  edot[1] = triangularMembershipFunction(errordot, cedot[0], cedot[1], cedot[1], cedot[2]); // NM
  edot[2] = triangularMembershipFunction(errordot, cedot[1], cedot[2], cedot[2], cedot[3]); // NS
  edot[3] = triangularMembershipFunction(errordot, cedot[2], cedot[3], cedot[3], cedot[4]); // ZE
  edot[4] = triangularMembershipFunction(errordot, cedot[3], cedot[4], cedot[4], cedot[5]); // PS
  edot[5] = triangularMembershipFunction(errordot, cedot[4], cedot[5], cedot[5], cedot[6]); // PM
  edot[6] = triangularMembershipFunction(errordot, cedot[5], cedot[6], 2, 3);      			// PB

  // Compute beta values and fuzzy output
  float y_final;
  float y_temp[7][7]; // Temporary output values for fuzzy logic
  float numerator = 0.0;
  float denominator = 0.0;

  for (int i = 0; i < 7; i++) {
    for (int j = 0; j < 7; j++) {
      // Max-Product method for fuzzy logic
      beta[i][j] = e[i] * edot[j];

      // Define fuzzy rule outputs based on the updated rules table
      for (int i = 0; i < 7; i++) {
          for (int j = 0; j < 7; j++) {
              if (i == 0 && j == 0) { // e = NB, edot = NB
                  y_temp[i][j] = y_out[0]; // NB
              } else if (i == 0 && j == 1) { // e = NB, edot = NM
                  y_temp[i][j] = y_out[0]; // NB
              } else if (i == 0 && j == 2) { // e = NB, edot = NS
                  y_temp[i][j] = y_out[1]; // NM
              } else if (i == 0 && j == 3) { // e = NB, edot = ZE
                  y_temp[i][j] = y_out[1]; // NM
              } else if (i == 0 && j == 4) { // e = NB, edot = PS
                  y_temp[i][j] = y_out[2]; // NS
              } else if (i == 0 && j == 5) { // e = NB, edot = PM
                  y_temp[i][j] = y_out[2]; // NS
              } else if (i == 0 && j == 6) { // e = NB, edot = PB
                  y_temp[i][j] = y_out[3]; // ZE

              } else if (i == 1 && j == 0) { // e = NM, edot = NB
                  y_temp[i][j] = y_out[0]; // NB
              } else if (i == 1 && j == 1) { // e = NM, edot = NM
                  y_temp[i][j] = y_out[1]; // NM
              } else if (i == 1 && j == 2) { // e = NM, edot = NS
                  y_temp[i][j] = y_out[1]; // NM
              } else if (i == 1 && j == 3) { // e = NM, edot = ZE
                  y_temp[i][j] = y_out[2]; // NS
              } else if (i == 1 && j == 4) { // e = NM, edot = PS
                  y_temp[i][j] = y_out[2]; // NS
              } else if (i == 1 && j == 5) { // e = NM, edot = PM
                  y_temp[i][j] = y_out[3]; // ZE
              } else if (i == 1 && j == 6) { // e = NM, edot = PB
                  y_temp[i][j] = y_out[4]; // PS

              } else if (i == 2 && j == 0) { // e = NS, edot = NB
                  y_temp[i][j] = y_out[1]; // NM
              } else if (i == 2 && j == 1) { // e = NS, edot = NM
                  y_temp[i][j] = y_out[1]; // NM
              } else if (i == 2 && j == 2) { // e = NS, edot = NS
                  y_temp[i][j] = y_out[2]; // NS
              } else if (i == 2 && j == 3) { // e = NS, edot = ZE
                  y_temp[i][j] = y_out[3]; // ZE
              } else if (i == 2 && j == 4) { // e = NS, edot = PS
                  y_temp[i][j] = y_out[3]; // ZE
              } else if (i == 2 && j == 5) { // e = NS, edot = PM
                  y_temp[i][j] = y_out[4]; // PS
              } else if (i == 2 && j == 6) { // e = NS, edot = PB
                  y_temp[i][j] = y_out[4]; // PS

              } else if (i == 3 && j == 0) { // e = ZE, edot = NB
                  y_temp[i][j] = y_out[1]; // NM
              } else if (i == 3 && j == 1) { // e = ZE, edot = NM
                  y_temp[i][j] = y_out[2]; // NS
              } else if (i == 3 && j == 2) { // e = ZE, edot = NS
                  y_temp[i][j] = y_out[3]; // ZE
              } else if (i == 3 && j == 3) { // e = ZE, edot = ZE
                  y_temp[i][j] = y_out[3]; // ZE
              } else if (i == 3 && j == 4) { // e = ZE, edot = PS
                  y_temp[i][j] = y_out[4]; // PS
              } else if (i == 3 && j == 5) { // e = ZE, edot = PM
                  y_temp[i][j] = y_out[5]; // PM
              } else if (i == 3 && j == 6) { // e = ZE, edot = PB
                  y_temp[i][j] = y_out[5]; // PM

              } else if (i == 4 && j == 0) { // e = PS, edot = NB
                  y_temp[i][j] = y_out[2]; // NS
              } else if (i == 4 && j == 1) { // e = PS, edot = NM
                  y_temp[i][j] = y_out[2]; // NS
              } else if (i == 4 && j == 2) { // e = PS, edot = NS
                  y_temp[i][j] = y_out[3]; // ZE
              } else if (i == 4 && j == 3) { // e = PS, edot = ZE
                  y_temp[i][j] = y_out[4]; // PS
              } else if (i == 4 && j == 4) { // e = PS, edot = PS
                  y_temp[i][j] = y_out[4]; // PS
              } else if (i == 4 && j == 5) { // e = PS, edot = PM
                  y_temp[i][j] = y_out[5]; // PM
              } else if (i == 4 && j == 6) { // e = PS, edot = PB
                  y_temp[i][j] = y_out[5]; // PM

              } else if (i == 5 && j == 0) { // e = PM, edot = NB
                  y_temp[i][j] = y_out[2]; // NS
              } else if (i == 5 && j == 1) { // e = PM, edot = NM
                  y_temp[i][j] = y_out[3]; // ZE
              } else if (i == 5 && j == 2) { // e = PM, edot = NS
                  y_temp[i][j] = y_out[4]; // PS
              } else if (i == 5 && j == 3) { // e = PM, edot = ZE
                  y_temp[i][j] = y_out[4]; // PS
              } else if (i == 5 && j == 4) { // e = PM, edot = PS
                  y_temp[i][j] = y_out[5]; // PM
              } else if (i == 5 && j == 5) { // e = PM, edot = PM
                  y_temp[i][j] = y_out[6]; // PB
              } else if (i == 5 && j == 6) { // e = PM, edot = PB
                  y_temp[i][j] = y_out[6]; // PB

              } else if (i == 6 && j == 0) { // e = PB, edot = NB
                  y_temp[i][j] = y_out[3]; // ZE
              } else if (i == 6 && j == 1) { // e = PB, edot = NM
                  y_temp[i][j] = y_out[4]; // PS
              } else if (i == 6 && j == 2) { // e = PB, edot = NS
                  y_temp[i][j] = y_out[4]; // PS
              } else if (i == 6 && j == 3) { // e = PB, edot = ZE
                  y_temp[i][j] = y_out[5]; // PM
              } else if (i == 6 && j == 4) { // e = PB, edot = PS
                  y_temp[i][j] = y_out[5]; // PM
              } else if (i == 6 && j == 5) { // e = PB, edot = PM
                  y_temp[i][j] = y_out[6]; // PB
              } else if (i == 6 && j == 6) { // e = PB, edot = PB
                  y_temp[i][j] = y_out[6]; // PB
              }
          }
      }

      // Calculate weighted average
      numerator += beta[i][j] * y_temp[i][j];
      denominator += beta[i][j];
    }
  }
  y_final = -(numerator / denominator);

  if (y_final > 1) y_final = 1;
  else if (y_final < -1) y_final = -1;

  return y_final;
}

void moveToInitialPosition(int initial_angle, int target_angle, int step_size) {
    while (initial_angle < target_angle) {
        // Chuyển đổi góc thành giá trị CCR cho PWM
        int ccr_value = (initial_angle * (high_servo - low_servo)) / 180 + low_servo;

        // Thiết lập giá trị cho PWM để đi ?u khiển servo
        __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, ccr_value);

        // Tăng góc từ từ
        initial_angle += step_size;

        // Giới hạn không vượt quá góc đích
        if (initial_angle > target_angle) {
            initial_angle = target_angle;
        }

        // Thêm delay để đảm bảo servo di chuyển từ từ
        HAL_Delay(30);
    }
}

// Hàm smoothTransition để đi ?u chỉnh current_angle từng bước v ? target_angle
float smoothTransition(float current, float target, float proportional_factor) {
    float error = target - current;
    float step = proportional_factor * fabs(error); // Calculate step size based on error

    // Ensure minimum step size to avoid "sticking" near the target
    if (step < 0.01f) {
        step = 0.01f;
    }

    // Adjust current towards target
    if (error > 0) {
        current += step;
        if (current > target) {
            current = target;
        }
    } else if (error < 0) {
        current -= step;
        if (current < target) {
            current = target;
        }
    }

    return current;
}

float stringToFloat(char* str)
{
    float result = 0.0;
    float decimalFactor = 0.1;
    int isDecimal = 0; // Biến để kiểm tra có phần thập phân không
    int isNegative = 0; // Kiểm tra số âm

    // Kiểm tra nếu là số âm
    if (*str == '-')
    {
        isNegative = 1;
        str++;
    }

    while (*str)
    {
        if (*str == '.') // Xử lý phần thập phân
        {
            isDecimal = 1;
        }
        else if (*str >= '0' && *str <= '9') // Xử lý phần nguyên và phần thập phân
        {
            if (!isDecimal)
            {
                result = result * 10 + (*str - '0');
            }
            else
            {
                result = result + (*str - '0') * decimalFactor;
                decimalFactor *= 0.1;
            }
        }
        str++;
    }

    if (isNegative)
    {
        result = -result;
    }

    return result;
}


// Hàm xử lý tín hiệu điều khiển
void processControlInput() {

    if (strncmp((char*)UART2_rxBuffer, "nnn", 3) == 0) {  // Kiểm tra nếu nhận 'nnn'
        flagStartControlLoop = 0;  // Dừng điều khiển
        sprintf((char*)txBuffer, "Stopped control loop.\n");
        HAL_UART_Transmit_IT(&huart2, txBuffer, strlen((const char*)txBuffer));  // Truyền thông điệp qua UART
    } else if (UART2_rxBuffer[2] == 'y') {  // Xác nhận giá trị điều khiển
        dis_setpoint = extractSetpoint((char*)UART2_rxBuffer);
        if (dis_setpoint >= MIN_SETPOINT && dis_setpoint <= MAX_SETPOINT) {
            sprintf((char*)txBuffer, "Setpoint updated to: %.1f\n", dis_setpoint);
            HAL_UART_Transmit_IT(&huart2, txBuffer, strlen((const char*)txBuffer));  // Truyền thông điệp qua UART
            flagStartControlLoop = 1;  // Bắt đầu hoặc tiếp tục điều khiển
        } else {
            sprintf((char*)txBuffer, "Invalid setpoint! Must be 0-50.\n");
            HAL_UART_Transmit_IT(&huart2, txBuffer, strlen((const char*)txBuffer));  // Truyền thông điệp qua UART
        }
    }
}


// Hàm trích xuất setpoint từ buffer UART
float extractSetpoint(char* buffer) {
    char setpointStr[3] = { buffer[0], buffer[1], '\0' };  // Lấy giá trị số đầu tiên và thứ hai
    return atof(setpointStr);  // Chuyển đổi sang float
}

void sendMessageIT(char *message) {
    uint8_t txBuffer[100]; // Đảm bảo txBuffer đủ lớn cho các chuỗi ngắn

    // Sao chép message vào txBuffer và truyền
    snprintf((char*)txBuffer, sizeof(txBuffer), "%s", message);
    HAL_UART_Transmit_IT(&huart2, txBuffer, strlen((const char*)txBuffer));
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
